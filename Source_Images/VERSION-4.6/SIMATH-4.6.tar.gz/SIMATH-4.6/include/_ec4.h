# ifndef __ARITH4__
#include<stdlib.h>
# include <_list.h>
# include <_arith1.h>
# include <_ec1.h>
# include <_pol1.h>
# include <_matr1.h>
# include <_pol2.h>
# include <_arith2.h>
# include <_ec2.h>
# include <_matr2.h>
# include <_pol3.h>
# include <_arith3.h>
# include <_ec3.h>
# include <_matr3.h>
# include <_pol4.h>
# include <_arith4.h>
# endif
# define __EC4__
