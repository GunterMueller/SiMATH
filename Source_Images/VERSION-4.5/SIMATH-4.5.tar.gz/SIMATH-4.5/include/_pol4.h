# ifndef __MATR3__
# include <_list.h>
# include <_arith1.h>
# include <_ec1.h>
# include <_pol1.h>
# include <_matr1.h>
# include <_pol2.h>
# include <_arith2.h>
# include <_ec2.h>
# include <_matr2.h>
# include <_pol3.h>
# include <_arith3.h>
# include <_ec3.h>
# include <_matr3.h>
# endif
# define __POL4__
 

# define    getdiprfrl(r1,r2,VL1,VL2)  fgetdiprfrl(r1,r2,VL1,VL2,stdin)

# define putdiprfrl(r1,r2,PL,VL1,VL2)  fputdiprfrl(r1,r2,PL,VL1,VL2,stdout)
